//
//  LVRecordTool.m
//  RecordAndPlayVoice
//
//  Created by PBOC peter on 16/3/1.
//  Copyright (c) 2015年 liuchunlao. All rights reserved.
//

#define KRecordFileName   @"TmpFile.aac"

#import "EMRecordTool.h"

@interface EMRecordTool () <AVAudioRecorderDelegate,AVAudioPlayerDelegate>

/** 播放器对象 */
@property (nonatomic, strong) AVAudioPlayer *player;

/** 定时器 */
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation EMRecordTool

static id instance;
#pragma mark - 单例
+ (instancetype)sharedRecordTool {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (instance == nil) {
            instance = [[self alloc] init];
        }
    });
    return instance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (instance == nil) {
            instance = [super allocWithZone:zone];
        }
    });
    return instance;
}


#pragma mark - public
- (void)startRecording {
    // 录音时停止播放 删除曾经生成的文件
    [self stopPlaying];
    [self deleteRecordingFile];
    [self changeAVAudioSessionCategory:AVAudioSessionCategoryRecord];
    
    
    [self.recorder record];

//    _timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateImage) userInfo:nil repeats:YES];
//    [_timer fire];
}
- (void)stopRecording {
    
    [_timer invalidate];
     _duration = self.recorder.currentTime;
    [self.recorder stop];
    
}

- (void)playRecordingFile {
    // 播放时停止录音
    [self.recorder stop];
    
    // 正在播放就返回
    if ([self.player isPlaying]) return;
    
    [self changeAVAudioSessionCategory:AVAudioSessionCategoryPlayback];
    
    [self.player play];
}

- (void)stopPlaying {
    [self.player stop];
}

- (void)deleteRecordingFile {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (self.urlRecordFile) {
        [fileManager removeItemAtURL:self.urlRecordFile error:NULL];
    }
}

#pragma mark - AVAudioRecorderDelegate
- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag {
    if (flag) {
        NSLog(@"录音成功");
    }
}
//当播放结束后调用这个方法
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    //按钮标题变为播放
    NSLog(@"结束录音调用的方法");

}


#pragma mark - 私有方法
#pragma mark ------ 根据音量 更改图片的大小
- (void)updateImage {
    
    [self.recorder updateMeters];
    double lowPassResults = pow(10, (0.05 * [self.recorder peakPowerForChannel:0]));
    float result  = 10 * (float)lowPassResults;
    NSLog(@"你妹的%f", result);
    int no = 1;
    if (result > 0 && result <= 1.5) {
        no = 1;
    } else if (result > 1.5 && result <= 2.5) {
        no = 2;
    } else if (result > 2.5 && result <= 3.5) {
        no = 3;
    } else if (result > 3.5 && result <= 5.0) {
        no = 4;
    } else if (result > 5.0 && result <= 8) {
        no = 5;
    } else if (result > 8 ) {
        no = 6;
    }
    
    if ([self.delegate respondsToSelector:@selector(recordTool:didstartRecoring:)]) {
        [self.delegate recordTool:self didstartRecoring: no];
    }
}
#pragma mark ------ 更改AVAudioSession 的类别
- (void)changeAVAudioSessionCategory:(NSString*)strCategory
{
    AVAudioSession *session = [AVAudioSession sharedInstance];//控制整个系统
    
    NSError *sessionError;
    
    [session setCategory:strCategory error:&sessionError];//播放的时候用的AVAudioSessionCategoryPlayback
    
    if (sessionError) {
        NSLog(@"设置AVAudioSession大管家的时候报的错_____%@",sessionError.description);
    }
    //判断后台有没有播放
    if (session == nil) {
        NSLog(@"AVAudioSession后台有播放:%@", [sessionError description]);
    } else {
        [session setActive:YES error:nil];
    }

    
}

#pragma mark - 懒加载
- (AVAudioRecorder *)recorder {
    if (!_recorder) {
        
        // 真机环境下需要的代码
        AVAudioSession *session = [AVAudioSession sharedInstance];
        NSError *sessionError;
        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
        
        if(session == nil)
            NSLog(@"Error creating session: %@", [sessionError description]);
        else
            [session setActive:YES error:nil];
        
        // 1.获取沙盒地址
        self.urlRecordFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingString:KRecordFileName]];//注意后缀  存在 tem 临时文件

        NSMutableDictionary* recordSettingAAC = [[NSMutableDictionary alloc] init];
        [recordSettingAAC setValue :[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
        [recordSettingAAC setValue:[NSNumber numberWithFloat:8000.0] forKey:AVSampleRateKey];//设置录音采样率(Hz) 如：AVSampleRateKey==8000/44100/96000（影响音频的质量）, 采样率必须要设为11025才能使转化成mp3格式后不会失真
        [recordSettingAAC setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];//录音通道数  1 或 2 ，要转换成mp3格式必须为双通道
        [recordSettingAAC setValue:[NSNumber numberWithInt:AVAudioQualityMin] forKey:AVEncoderAudioQualityKey];
        // [recordSettingAAC setValue:[NSNumber numberWithInt:16] forKey:AVEncoderBitRateKey];//ios7 可以 ios9 不行
        [recordSettingAAC setObject:@(8) forKey:AVLinearPCMBitDepthKey]; //线性采样位数  8、16、24、32
        [recordSettingAAC setObject:@(YES) forKey:AVLinearPCMIsFloatKey]; //是否使用浮点数采样
      
        NSError *error;
        _recorder = [[AVAudioRecorder alloc] initWithURL:self.urlRecordFile settings:recordSettingAAC error:&error];
        if (error || self.recorder == nil) {
            NSLog(@"录音创建时候的错误___%@",error.description);
        }
        _recorder.delegate = self;
        _recorder.meteringEnabled = YES;
        [_recorder prepareToRecord];
    }
    return _recorder;
}
- (AVAudioPlayer *)player
{
    if (_player == nil) {
        
        _player = [[AVAudioPlayer alloc] initWithContentsOfURL:self.urlRecordFile error:NULL];
        _player.delegate = self;
    }
    return _player;
}




//        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
//        NSString *filePath = [path stringByAppendingPathComponent:LVRecordFielName];
//        self.recordFileUrl = [NSURL fileURLWithPath:filePath];
//        NSLog(@"%@", filePath);
/*******融云kit的语音参数*****/
//NSDictionary *settings = @{AVFormatIDKey: @(kAudioFormatLinearPCM),
//                           AVSampleRateKey: @8000.00f,
//                           AVNumberOfChannelsKey: @1,
//                           AVLinearPCMBitDepthKey: @16,
//                           AVLinearPCMIsNonInterleaved: @NO,
//                           AVLinearPCMIsFloatKey: @NO,
//                           AVLinearPCMIsBigEndianKey: @NO};

@end
