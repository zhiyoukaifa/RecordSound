//
//  ViewController.m
//  EMAppleRecordSound
//
//  Created by 张三 on 16/10/17.
//  Copyright © 2016年 全球e家电子商务有限公司. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"



@interface ViewController ()<AVAudioPlayerDelegate,AVAudioRecorderDelegate>
{

     NSURL *mp3FilePath;
}

//录音按钮
@property (weak, nonatomic) IBOutlet UIButton *recordButton;

//播放按钮
@property (weak, nonatomic) IBOutlet UIButton *playButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    //刚打开的时候录音状态为不录音
    self.isRecoding = NO;
    
    //播放按钮不能被点击
    [self.playButton setEnabled:NO];
    //播放按钮设置成半透明
    self.playButton.titleLabel.alpha = 0.5;
    
    //创建临时文件来存放录音文件
      self.tmpFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingString:@"TmpFile.aac"]];//注意后缀 tem 临时文件
    //设置后台播放
    AVAudioSession *session = [AVAudioSession sharedInstance];//控制整个系统
    NSError *sessionError;
    [session setCategory:AVAudioSessionCategoryRecord error:&sessionError];//播放的时候用的AVAudioSessionCategoryPlayback
    
  
    
 }

//录音按钮方法的实现
- (IBAction)startStopRecord:(id)sender {
    
    //判断当录音状态为不录音的时候
    if (!self.isRecoding) {
        //将录音状态变为录音
        self.isRecoding = YES;
        
        //将录音按钮变为停止
        [self.recordButton setTitle:@"停止" forState:UIControlStateNormal];
        
        //播放按钮不能被点击
        [self.playButton setEnabled:NO];
        self.playButton.titleLabel.alpha = 0.5;
        
        
    
//      [NSNumber numberWithInt:AVAudioQualityMin],AVEncoderAudioQualityKey, nil];   //录音的质量
       
        NSMutableDictionary* recordSettingAAC = [[NSMutableDictionary alloc] init];
        [recordSettingAAC setValue :[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
        [recordSettingAAC setValue:[NSNumber numberWithFloat:32000.0] forKey:AVSampleRateKey];//设置录音采样率(Hz) 如：AVSampleRateKey==8000/44100后台转MP3 不失真/96000（影响音频的质量）, 采样率必须要设为11025才能使转化成mp3格式后不会失真
        [recordSettingAAC setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];//录音通道数  1 或 2 ，要转换成mp3格式必须为双通道
        [recordSettingAAC setValue:[NSNumber numberWithInt:AVAudioQualityMin] forKey:AVEncoderAudioQualityKey];
//        表示单位时间（1秒）内传送的比特数bps（bit per second，位/秒）的速度。作为一种数字音乐压缩效率的参考性指标，通常使用kbps（通俗地讲就是每秒钟1024比特）作为单位。
//        [recordSettingAAC setValue:[NSNumber numberWithInt:128000] forKey:AVEncoderBitRateKey];//ios7 可以 ios9 不行 128000
        //每个采样点位数,分为8、16、24、32 采样位数——可以理解数字音频设备处理声音的解析度，即对声音的辨析度。就像表示颜色的位数一样（8位表示256种颜色，16位表示65536种颜色），有8位，16位，24位等。这个数值越大，解析度就越高，录制和回放的声音就越真实。
        [recordSettingAAC setObject:@(8) forKey:AVLinearPCMBitDepthKey]; //线性采样位数  8、16、24、32
//        //是否使用浮点数采样
//         [recordSettingAAC setObject:@(YES) forKey:AVLinearPCMIsFloatKey];
        NSError *error;
        
        NSMutableDictionary *settings = [[NSMutableDictionary alloc] init];
        [settings setObject:[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey:AVFormatIDKey];
        [settings setObject:[NSNumber numberWithFloat:11025.0] forKey:AVSampleRateKey];
        [settings setObject:[NSNumber numberWithInt:2] forKey:AVNumberOfChannelsKey];
        [settings setObject:[NSNumber numberWithInt:12800] forKey:AVEncoderBitRateKey];
        [settings setObject:[NSNumber numberWithInt:16] forKey:AVLinearPCMBitDepthKey];
        [settings setObject:[NSNumber numberWithInt:AVAudioQualityLow] forKey:AVEncoderAudioQualityKey];
        //开始录音,将所获取到得录音存到文件里 _tmpFile后缀名对应着AVFormatIDKey
        self.recorder = [[AVAudioRecorder alloc] initWithURL:_tmpFile settings:recordSettingAAC error:&error];
        if (error || self.recorder == nil) {
            NSLog(@"录音报错___%@",error.description);

        }
        
        //准备记录录音
        [_recorder prepareToRecord];
        
        //启动或者恢复记录的录音文件
        [_recorder record];
        _recorder.delegate = self;
        _player = nil;
        
    } else {
        
        //录音状态 点击录音按钮 停止录音
        self.isRecoding = NO;
        [self.recordButton setTitle:@"录音" forState:UIControlStateNormal];
        
        //录音停止的时候,播放按钮可以点击
        [self.playButton setEnabled:YES];
        [self.playButton.titleLabel setAlpha:1];
        
        //停止录音
        [_recorder stop];
        
        _recorder = nil;
        
    }
    
}

- (void)testPlay
{
    
    //设置后台播放
    AVAudioSession *session = [AVAudioSession sharedInstance];//控制整个系统
    
    NSError *sessionError;
    
    [session setCategory:AVAudioSessionCategoryPlayback error:&sessionError];//播放的时候用的AVAudioSessionCategoryPlayback
    
    
    
    NSError *playError;
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:_tmpFile error:&playError];
    //当播放录音为空, 打印错误信息
    if (self.player == nil) {
        NSLog(@"播放器的问题: %@", [playError description]);
    }
    self.player.delegate = self;

}

//播放按钮方法的实现
- (IBAction)playPause:(id)sender {
    
    //判断是否正在播放,如果正在播放
    if ([self.player isPlaying]) {
        //暂停播放
        [_player pause];
        
        //按钮显示为播放
        [self.playButton setTitle:@"播放" forState:UIControlStateNormal];
        
    } else {
        AVAudioSession *session = [AVAudioSession sharedInstance];//控制整个系统
        
        NSError *sessionError;
        [session setCategory:AVAudioSessionCategoryPlayback error:&sessionError];//播放的时候用的AVAudioSessionCategoryPlayback

        //开始播放
        [_player play];
        
        //
        [self.playButton setTitle:@"暂停" forState:UIControlStateNormal];
        
    }
    
}


//当播放结束后调用这个方法
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    //按钮标题变为播放
    [self.playButton setTitle:@"播放" forState:UIControlStateNormal];
}
- (IBAction)uploadVoice:(id)sender
{
    [self upload];
}
- (void)upload
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer    = [AFHTTPResponseSerializer serializer];
    manager.requestSerializer     = [AFHTTPRequestSerializer serializer];
    manager.requestSerializer.timeoutInterval = 10;
    NSData *dataVoice = [NSData dataWithContentsOfURL:_tmpFile];//dataWithContentsOfURL
//     NSData *dataVoice     = [NSData dataWithContentsOfFile:@"/private/var/mobile/Applications/32C63B31-AEDD-4EF2-8657-B4D9FBFA55E6/tmp/myselfRecord.mp3"];
//    NSLog(@"dataVoice___%@____%@",dataVoice,self.tmpFile);
    
    if (!dataVoice) {
        
        NSLog(@"空空");
        
        return;
    }
    //获得沙盒中的视频内容
    
    
    //   manager.responseSerializer.acceptableContentTypes =[NSSet setWithObject:@"text/html"];//不写这句话也可以
    //上传文件流
    [manager POST:@"http://192.168.5.142:8080/eplat/upload/uploadMedia" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
        //zs0219 name 不能换 只能是file
        //         [formData appendPartWithFileURL:_tmpFile name:@"file" fileName:@"file.mp3" mimeType:@"video/mpeg4" error:nil];
        [formData appendPartWithFileData:dataVoice name:@"file" fileName:@"text.aac" mimeType:@"audio/mpeg3"];
        
        //        [formData appendPartWithFileData:dataVoice name:@"file" fileName:@"TmpFile" mimeType:@"audio/mpeg3"];
        //zs0119 fileName: 后台看见的文件名称 .png后台返回的图片的后缀名
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        
        
        NSLog(@"上传图片返回来的数据_______%@",responseObject);
        NSError * error = nil;
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:&error];
        NSLog(@"______%@",dic.description);
        
        if (!error) {
            
            
        } else {
            
            NSLog(@"JSON解析数据失败");
            
        }
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        NSLog(@"顶顶顶顶");
        
    }];

}
- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
    NSLog(@"录音成功  %@",recorder);
    
    [self testPlay];

}

- (void)audioRecorderEncodeErrorDidOccur:(AVAudioRecorder *)recorder error:(NSError * __nullable)error
{
    NSLog(@"————————%@",error.description);

}
























- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
