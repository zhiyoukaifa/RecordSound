//
//  main.m
//  EMAppleRecordSound
//
//  Created by 张三 on 16/10/17.
//  Copyright © 2016年 全球e家电子商务有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
